//
//  Goods.swift
//  AppWithTable
//
//  Created by Alexander Zub on 01.08.2022.
//

import Foundation

struct Goods {
    let count: Int
    let name: String
}
