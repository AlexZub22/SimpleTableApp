//
//  ViewController.swift
//  AppWithTable
//
//  Created by Alexander Zub on 01.08.2022.
//

import UIKit

class ViewController: UIViewController {
    
    var goodsArray: [Goods] = [
        Goods(count: 2, name: "Молоко"),
        Goods(count: 3, name: "Хлеб"),
        Goods(count: 4, name: "Яблоки")]
    
    @IBOutlet weak var table: UITableView!
    
    @IBOutlet weak var goodsTitleTextField: UITextField!
    @IBOutlet weak var goodsCountTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        table.backgroundColor = .systemMint
        table.dataSource = self // Источник данных
        table.delegate = self
        dismissKeyboardOnTap()
    }
//все actions обычно ниже viewDidLoad
    
    @IBAction func addTap(_ sender: UIButton) {
        guard let title = goodsTitleTextField.text else {
            return
        }
        guard let count = Int(goodsCountTextField.text!) else {
            return
        }
        //создать товар на основе введенных данных
        let goods = Goods(count: count, name: title)
        //добавить его в массив
        goodsArray.append(goods)
        //отобразить в таблице
        self.table.reloadData()
        goodsTitleTextField.text = nil
        goodsCountTextField.text = nil
    }
    //закрытие клавиатуры
    func dismissKeyboardOnTap() {
        //создаем жест - тап
        let tap = UITapGestureRecognizer.init(target: self, action: #selector(dismissKeys))
        self.view.addGestureRecognizer(tap)
    }
    @objc func dismissKeys() {
        self.view.endEditing(true)
    }
    
}
extension ViewController: UITableViewDelegate {
    //удаление по свайпу влево
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Удалить") { _, _, complition in
            self.goodsArray.remove(at: indexPath.row)
            self.table.reloadData()
            complition(true)
        }
        let config = UISwipeActionsConfiguration(actions: [deleteAction]) //в массиве кнопки выходящие при свайпе
        return config
    }
}

extension ViewController: UITableViewDataSource {
    //Указывает таблице, сколько необходимо выделить строк
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return goodsArray.count
    }
    //Создает, заполняет данными и возвращает ячейку
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
        //indexPath - это адрес ячейки
        //два свойства:
        //indexPath.section - адрес секции, типа Int (секции - блок строк(ячеек))
        //indexPath.row - адрес строки, типа Int
        cell.textLabel?.text = goodsArray[indexPath.row].name
        cell.detailTextLabel?.text = "\(goodsArray[indexPath.row].count) шт."
        return cell
    }
}
